# Sign Language > 2026-01-01 2:11am
https://universe.roboflow.com/my-projects-szuja/sign-language-pbjqm

Provided by a Roboflow user
License: CC BY 4.0

